#include <stdio.h>

#define TAMANHO 30

int main() {
    double faturamento[TAMANHO] = {2000, 3000, 1500, 0, 4000, 5000, 0, 0, 1800, 6000, 
                                   7000, 8000, 9000, 0, 10000, 20000, 500, 300, 400, 
                                   6000, 8000, 0, 9000, 0, 2500, 3200, 1000, 600, 700, 0};
    double menor = faturamento[0], maior = faturamento[0], soma = 0, media;
    int dias_com_faturamento = 0, dias_acima_media = 0;

    
    for (int i = 0; i < TAMANHO; i++) {
        if (faturamento[i] > 0) {  
            if (faturamento[i] < menor) {
                menor = faturamento[i];
            }
            if (faturamento[i] > maior) {
                maior = faturamento[i];
            }
            soma += faturamento[i];
            dias_com_faturamento++;
        }
    }

    /
    media = soma / dias_com_faturamento;

    
    for (int i = 0; i < TAMANHO; i++) {
        if (faturamento[i] > media) {
            dias_acima_media++;
        }
    }

    printf("Menor faturamento: R$ %.2f\n", menor);
    printf("Maior faturamento: R$ %.2f\n", maior);
    printf("Número de dias com faturamento acima da média: %d\n", dias_acima_media);

    return 0;
}
