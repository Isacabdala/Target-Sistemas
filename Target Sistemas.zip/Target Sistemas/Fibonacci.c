#include <stdio.h>

int pertenceFibonacci(int numero) {
    int a = 0, b = 1, proximo;

    if (numero == 0 || numero == 1) {
        return 1; 
    }

    while (b <= numero) {
        proximo = a + b;
        a = b;
        b = proximo;

        if (b == numero) {
            return 1; 
        }
    }

    return 0; 
}

int main() {
    int numero;

    printf("Informe um número: ");
    scanf("%d", &numero);

    if (pertenceFibonacci(numero)) {
        printf("%d pertence à sequência de Fibonacci.\n", numero);
    } else {
        printf("%d não pertence à sequência de Fibonacci.\n", numero);
    }

    return 0;
}
